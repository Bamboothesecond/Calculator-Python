from tkinter import *

# Create the GUI window
root = Tk()
root.title("Ronaldculator")
root.geometry("280x370")
root.configure(bg="#1c1c1c")  # Set background color
root.resizable(False,False)

# Create the input box
input_box = Entry(root, width=15, font=("Arial", 20), bd=3, justify="right")
input_box.place(x=20, y=20, height=60)

# Create validation function to allow only numbers in the entry box
def validate_input(new_value):
    if all(c.isdigit() or c in "+-*/." for c in new_value):
        return True
    else:
        return False

# Create validation command for the entry box
validation_cmd = root.register(validate_input)

# Apply the validation to the input box
input_box.config(validate="key", validatecommand=(validation_cmd, '%P'))


# Define the button click functions
def button_click(number):
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + str(number))
    input_box.config(state='readonly')


def button_clear():
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.config(state='readonly')


def button_add():
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + "+")
    input_box.config(state='readonly')


def button_subtract():
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + "-")
    input_box.config(state='readonly')


def button_multiply():
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + "*")
    input_box.config(state='readonly')


def button_divide():
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + "/")
    input_box.config(state='readonly')


def button_equal():
    second_number = input_box.get().replace(" ", "")
    input_box.config(state='normal')
    input_box.delete(0, END)

    try:
        result = eval(second_number)
        result_str = "{:.2f}".format(result)  # format the result with 2 decimal places
        input_box.insert(0, result_str)
    except ZeroDivisionError:
        input_box.insert(0, "Cannot divide by zero")
    except:
        input_box.insert(0, "Invalid input")

    input_box.config(state='readonly')


def add_decimal():
    current = input_box.get()
    input_box.config(state='normal')
    input_box.delete(0, END)
    input_box.insert(0, str(current) + ".")
    input_box.config(state='readonly')


def keys(event):
    key = event.char
    if key.isdigit():
        if key == '0':
            button_0.invoke()
        elif key == '1':
            button_1.invoke()
        elif key == '2':
            button_2.invoke()
        elif key == '3':
            button_3.invoke()
        elif key == '4':
            button_4.invoke()
        elif key == '5':
            button_5.invoke()
        elif key == '6':
            button_6.invoke()
        elif key == '7':
            button_7.invoke()
        elif key == '8':
            button_8.invoke()
        elif key == '9':
            button_9.invoke()
    elif key == '+':
        button_add.invoke()
    elif key == '-':
        button_subtract.invoke()
    elif key == '*':
        button_multiply.invoke()
    elif key == '/':
        button_divide.invoke()
    elif key == '.':
        add_decimal()
    elif key == '\r' or key == '\n':  # Enter key
        button_equal.invoke()
    elif key == '\x08':  # Backspace key
        button_clear.invoke()


root.bind('<Key>', keys)

# Define the buttons
button_1 = Button(root, text="1", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(1))
button_2 = Button(root, text="2", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(2))
button_3 = Button(root, text="3", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(3))
button_4 = Button(root, text="4", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(4))
button_5 = Button(root, text="5", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(5))
button_6 = Button(root, text="6", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(6))
button_7 = Button(root, text="7", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(7))
button_8 = Button(root, text="8", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(8))
button_9 = Button(root, text="9", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(9))
button_0 = Button(root, text="0", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=10, command=lambda: button_click(0))
button_add = Button(root, text="+", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=17, pady=5, command=button_add)
button_subtract = Button(root, text="-", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=5, command=button_subtract)
button_multiply = Button(root, text="*", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=19, pady=5, command=button_multiply)
button_divide = Button(root, text="/", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=20, pady=5, command=button_divide)
button_equal = Button(root, text="=", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=17, pady=10, command=button_equal)
button_clear = Button(root, text="C", font=("Arial", 18), bg="#ff8500", fg="#ffffff", padx=17, pady=10, command=button_clear)
button_decimal = Button(root, text=".", font=("Arial", 18), bg="#3f3f3f", fg="#ffffff", padx=23, pady=10, command=add_decimal)

# Bind the events related to the keys to the input box
input_box.bind('<Key>', lambda e: 'break')  # Prevent any key press event
input_box.bind('<KeyRelease>', lambda e: e.widget.event_generate('<<TextModified>>')) # Generate a custom event when the text is modified

# Place the buttons on the GUI
# x = left, y = right, less = upwards
button_1.place(x=5, y=96)
button_2.place(x=75, y=96)
button_3.place(x=140, y=96)
button_4.place(x=5, y=163)
button_5.place(x=75, y=163)
button_6.place(x=140, y=163)
button_7.place(x=5, y=229)
button_8.place(x=75, y=229)
button_9.place(x=140, y=229)
button_0.place(x=73, y=296)
button_clear.place(x=5, y=296)
button_equal.place(x=145, y=296)
button_add.place(x=212, y=92)
button_subtract.place(x=212, y=147)
button_multiply.place(x=212, y=202)
button_divide.place(x=212, y=257)
button_decimal.place(x=212, y=312)

root.mainloop()